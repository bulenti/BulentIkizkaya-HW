package ikizkaya.bulent.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class School {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String nameofSchool;
    private String faculty;
    private String course;
    private String city;


    @OneToOne
    private Student student;

    @OneToMany
    private List<Student> studentList = new ArrayList<>();


    public School(){
    }

    public School(String nameofSchool, String faculty, String course, String city) {
        this.nameofSchool = nameofSchool;
        this.faculty = faculty;
        this.course = course;
        this.city = city;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNameofSchool() {
        return nameofSchool;
    }

    public void setNameofSchool(String nameofSchool) {
        this.nameofSchool = nameofSchool;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    @Override
    public String toString() {
        return "School{" +
                "id=" + id +
                ", nameofSchool='" + nameofSchool + '\'' +
                ", faculty='" + faculty + '\'' +
                ", course='" + course + '\'' +
                ", city='" + city + '\'' +
                '}';
    }
}
