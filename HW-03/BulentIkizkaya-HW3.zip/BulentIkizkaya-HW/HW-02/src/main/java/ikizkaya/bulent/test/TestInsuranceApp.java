package ikizkaya.bulent.test;

import jakarta.persistence.EntityManager;
import ikizkaya.bulent.model.School;
import ikizkaya.bulent.model.Student;
import ikizkaya.bulent.utility.EntityManagerUtils;

public class TestInsuranceApp {
    public static void main(String[] args) {

        saveTestData();
    }
    private static void saveTestData(){

        Student student1 = new Student("Hale","KIRMAZ","Female",112262365123L,2000);
        Student student2 = new Student("Yılmaz", "KIRMAZ", "Male", 22334455667L,  1998);
        Student student3 = new Student("Osman", "TURGUT", "Male", 33445566778L, 1999);
        Student student4 = new Student("Sinan", "OCAK", "Male",44556677889L, 2001);
        Student student5 = new Student("Semra","HOŞDERE","Female",44556677889L,1997);

        School sc1 = new School("Sabanci","Science","IT","istanbul");
        School sc2 = new School("Dokuz Eylul","Science","IT","izmir");
        School sc3 = new School("ODTU","Science","Civil","Ankara");


        sc1.setStudent(student1);
        sc1.setStudent(student2);
        sc2.setStudent(student3);
        sc3.setStudent(student4);
        sc3.setStudent(student5);

        EntityManager entityManager= EntityManagerUtils.getEntityManager("mysqlPU");


        try {
            entityManager.getTransaction().begin();
            entityManager.persist(sc1);
            entityManager.persist(sc2);
            entityManager.persist(sc3);

            entityManager.persist(student1);
            entityManager.persist(student2);
            entityManager.persist(student3);
            entityManager.persist(student4);
            entityManager.persist(student5);

            entityManager.getTransaction().commit();
            System.out.println("All data persisted!");

        } catch (Exception e) {
            entityManager.getTransaction().rollback();
        } finally {
            EntityManagerUtils.closeEntityManager(entityManager);
        }

    }

}
